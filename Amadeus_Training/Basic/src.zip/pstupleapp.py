def sqr_n_cube(value):
    return value ** 2, value ** 3


print(sqr_n_cube(5))
