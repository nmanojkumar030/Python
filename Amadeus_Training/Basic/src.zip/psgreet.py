name = 'amadeus'
city = 'Bengaluru'

print('name :', name)
print('city :', city)
