def power(x, n=0):
    """Positional argument function / fixed argument"""
    return x ** n


print(power(4, 5))
print(power(5))
