from builtins import print, int

n = 15

print(n)
print(type(n))
print()

# repr
print(0xf)
print(0o17)
print(0b1111)

print(int('f', 16))
print(int('f', 16))
print(int('17', 8))
print(int('1111', 2))

print(0.003)
print(3E-3)
print(3e-3)

print(5.8/2)
print(5.8//2)
