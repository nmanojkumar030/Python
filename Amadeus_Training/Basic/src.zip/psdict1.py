

info = dict()  # {}
print(info)
print(len(info))
print(type(info))
