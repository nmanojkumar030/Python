s = 'python'  # immutable objects, unicode

file_path = 'c:\templates\blues\rules\folder99\neon\temp.txt'
print(file_path)
print()


file_path = 'c:\\templates\\blues\\rules\\folder99\\neon\\temp.txt'
print(file_path)
print()

file_path = r'c:\templates\blues\rules\folder99\neon\temp.txt'
print(file_path)
print()


# String Indexing

print(s[0])
print(s[1])
print(s[2])
print(s[3])
print(s[4])

print(s[0])
print(s[-1])
print(s[-2])
print(s[-3])
print(s[-4])


# String Slicing




